--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'

SELECT 
k.sensei_program as [Program Id],
k.sensei_programname as [Program Name],
k.sensei_keydateid as [KeyDate Id],
k.sensei_name as [Key Date Name],
k.sensei_date as [Date],
k.sensei_description as [Description],
k.statuscodename as [Status],
case 
	when k.statuscodename = 'Done' then 0
	when k.sensei_date < Getdate() then 4 
    when k.sensei_date is null then 3 
	else 1 
	end as StatusKPI,

case
	when k.statuscodename = 'Done' then 'Completed'
	when k.sensei_date < Getdate() then 'Overdue' 
    when k.sensei_date is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,

KeyDate_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_keydate&id=',k.sensei_keydateid)


FROM [dbo].[sensei_keydate] k
	CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

WHERE k.sensei_program is not null
   and sensei_program = (@ProgUID)