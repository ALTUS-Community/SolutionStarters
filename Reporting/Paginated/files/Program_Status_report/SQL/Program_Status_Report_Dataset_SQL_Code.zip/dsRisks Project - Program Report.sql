--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'

SELECT 
	r.sensei_program AS [Program Id],
	r.sensei_programname as [Program Name],
	r.sensei_riskid as [Risk Id] ,
	r.sensei_name AS [Risk Name],
	r.sensei_assignedtoyominame as [Assigned To],
	r.sensei_riskownername as [Risk Owner],
	r.sensei_categoryname as [Category],
	r.statuscodename as [Status],
	r.sensei_likelihoodname as [Likelihood],
	r.sensei_consequencename as [Consequence],
	r.sensei_riskscore as [Risk Score],
	CONCAT(RIGHT(r.sensei_likelihood,1),RIGHT(r.sensei_consequence,1)) AS [RiskMatrixScore],
	r.sensei_cost as [Cost],
	r.sensei_description as [Description],
	r.sensei_mitigationplan as [Mitigation Plan],
	r.sensei_contingencyplan as [Contigency Plan],
	r.sensei_triggerdescription as [Trigger Description],
	r.sensei_triggername as [Trigger],
	r.sensei_duedate as [Due Date],
	CASE 
		WHEN r.statuscodename = 'Postponed' THEN 2
		WHEN r.statuscodename <> 'Active' THEN 0
		WHEN r.sensei_duedate < Getdate() THEN 4 
		WHEN r.sensei_duedate is null THEN 3 
		ELSE 1 
		END AS StatusKPI,

	CASE 
		WHEN r.statuscodename = 'Postponed' THEN 'Postponed'
		WHEN r.statuscodename <> 'Active' THEN 'Completed'
		WHEN r.sensei_duedate < Getdate() THEN 'Overdue' 
		WHEN r.sensei_duedate is null THEN 'Due Date Missing'
		ELSE 'On Track' 
		END AS StatusKPITooltip,

	r.[sensei_includeinprogramreportname] as [Include in Program Report],
	r.[sensei_includeinpsrname] as [Include in PSR],
	Risk_URL = CONCAT('https://', @EnvironmentURL, '.dynamics.com/main.aspx?appid=', app.appmoduleid, '&pagetype=entityrecord&etn=sensei_risk&id=', r.sensei_riskid),
	p.sensei_name AS [Project Name]  -- Selecting ProjectName from sensei_project table

FROM [dbo].[sensei_risk] r  
	LEFT JOIN dbo.sensei_project p ON p.sensei_projectid = r.sensei_project 
	CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
WHERE p.sensei_program IS NOT NULL AND p.sensei_program = @ProgUID  and r.sensei_includeinpsr = 1