--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '6843E465-B752-EF11-BFE3-000D3AE1A88F'

SELECT 
	* ,
	StatusUpdate_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_statusupdate&id=',st.[Status Update Id])
	FROM(
		SELECT x.sensei_program as [Program Id],
			   x.CreatedOn as [Created On],
			   x.[sensei_statusdate] as [Status Date],
			   X.Statuscomment as [Status Comment],
			   x.KPIType,
			   x.KPI,
			   x.[sensei_statusupdateid] as [Status Update Id],
			   CASE
				 WHEN x.sensei_program IS NOT NULL THEN Row_number()
				 OVER (
				   partition BY x.sensei_program, x.KPIType
				   ORDER BY x.sensei_statusdate DESC)
				 ELSE NULL
			   END AS ProjectCommentRN,
			   CASE
				 WHEN x.sensei_program IS NOT NULL THEN Row_number()
				 OVER (
				   partition BY x.sensei_program, x.KPIType, x.[sensei_statusdate]
				   ORDER BY x.sensei_statusdate DESC)
				 ELSE NULL
			   END AS ProjectCommentRNPM

		FROM   (SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_changerequestsstatus as Statuscomment,
					   'Change Status KPI' AS 'KPIType',
						CASE [sensei_changerequestskpi]
							--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_program IS NOT NULL AND s.sensei_program = (@ProgUID))
				UNION ALL
				SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_projectstatus,
					   'Project KPI'  AS 'KPIType',
					   CASE [sensei_projectkpi]
						 	--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_program IS NOT NULL AND s.sensei_program = (@ProgUID))
				UNION ALL
				SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_financialsstatus,
					   'Financials KPI' AS 'KPIType',
					   CASE [sensei_financialskpi]
							--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  (s.sensei_program IS NOT NULL )
				UNION ALL
				SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_deliverablesstatus,
					   'Deliverable KPI' AS 'KPIType',
					   CASE [sensei_deliverableskpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_program IS NOT NULL AND s.sensei_program = (@ProgUID))
				UNION ALL
				SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_risksstatus,
					   'Risk KPI' AS 'KPIType',
					   CASE [sensei_riskskpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  (s.sensei_program IS NOT NULL )
				UNION ALL
				SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_issuesstatus,
					   'Issue KPI' AS 'KPIType',
					   CASE [sensei_issueskpi]
							--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  (s.sensei_program IS NOT NULL )
				UNION ALL
				SELECT 
					  s.sensei_program as sensei_program,
					  s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_schedulestatus,
					   'Schedule KPI' AS 'KPIType',
					   CASE [sensei_schedulekpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_program IS NOT NULL AND s.sensei_program = (@ProgUID))
				UNION ALL
				SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_workstatus,
					   'Work KPI' AS 'KPIType',
					   CASE [sensei_workkpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_program IS NOT NULL AND s.sensei_program = (@ProgUID))
				UNION ALL
				SELECT 
					   s.sensei_program as sensei_program,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_changerequestsstatus,
					   'Change Request KPI' AS 'KPIType',
					   CASE [sensei_changerequestskpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  ( s.sensei_program IS NOT NULL AND s.sensei_program = (@ProgUID))
				) X  
			 
				 WHERE x.sensei_program = (@ProgUID)
			) AS st
		CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

		WHERE st.ProjectCommentRN <= 2
		ORDER BY [Program Id], KPIType, ProjectCommentRN