--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'

SELECT 

i.sensei_program as [Program Id],
i.sensei_programname as [Program Name] ,
i.sensei_issueid as [Issue Id],
i.sensei_name as [Issue Name],
i.sensei_assignedtoname [Assigned To],
i.statuscodename as [Status],
i.sensei_categoryname as [Category] ,
i.sensei_priorityname as [Priority],
i.sensei_duedate as [Due Date],
i.sensei_description as [Description],
i.sensei_resolution as [Resolution],
i.sensei_linkedtorisk [Linked To Risk ID],
i.sensei_linkedtoriskname as [Linked To Risk],
case 
	when i.statuscodename = 'Postponed' then 2
    when i.statuscodename <> 'Active' then 0
	when i.sensei_duedate < Getdate() then 4 
        when i.sensei_duedate is null then 3 
	else 1 
	end as StatusKPI,

case 
	when i.statuscodename = 'Postponed' then 'Postponed'
	when i.statuscodename <> 'Active' then 'Completed'
	when i.sensei_duedate < Getdate() then 'Overdue' 
    when i.sensei_duedate is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,

i.[sensei_includeinprogramreportname] as [Include in Program Report],
i.[sensei_includeinpsrname] as [Include in PSR],
Issue_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_issue&id=',i.sensei_issueid)


 FROM [dbo].[sensei_issue] i 
 CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
 where i.sensei_program is not null and i.sensei_program = (@ProgUID)
and i.sensei_includeinprogramreport = 1