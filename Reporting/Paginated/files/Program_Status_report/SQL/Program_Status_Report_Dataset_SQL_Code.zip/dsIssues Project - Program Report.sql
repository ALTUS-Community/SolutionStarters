Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProgUID varchar(50)
set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'

SELECT 

	i.sensei_project as [Project Id],
	i.sensei_projectname as [Project Name],
	p.sensei_program as [Project Program Id],
	i.sensei_programname as [Program Name],
	i.sensei_issueid as [Issue Id],
	i.sensei_name as [Issue Name],
	i.sensei_assignedtoname as [Assigned To],
	i.statuscodename as [Status],
	i.sensei_categoryname as [Category],
	i.sensei_priorityname as [Priority],
	i.sensei_duedate as [Due Date],
	i.sensei_description as [Description],
	i.sensei_resolution [Resolution],
	i.sensei_linkedtorisk as [Linked To Risk ID],
	i.sensei_linkedtoriskname as [Linked To Risk],
	CASE 
		WHEN i.statuscodename = 'Postponed' THEN 2
		WHEN i.statuscodename <> 'Active' THEN 0
		WHEN i.sensei_duedate < Getdate() THEN 4 
			WHEN i.sensei_duedate is null THEN 3 
		ELSE 1 
		END AS StatusKPI,

	CASE 
		WHEN i.statuscodename = 'Postponed' THEN 'Postponed'
		WHEN i.statuscodename <> 'Active' THEN 'Completed'
		WHEN i.sensei_duedate < Getdate() THEN 'Overdue' 
		WHEN i.sensei_duedate is null THEN 'Due Date Missing'
		ELSE 'On Track' 
		END AS StatusKPITooltip,

	i.[sensei_includeinprogramreportname] as [Include in Program Report],
	i.[sensei_includeinpsrname] as [Include in PSR],
	Issue_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_issue&id=',i.sensei_issueid)


	FROM [dbo].[sensei_issue] i 
		LEFT JOIN ( SELECT sensei_projectid, sensei_program FROM dbo.sensei_project) p ON p.sensei_projectid = i.sensei_project 
		CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
	WHERE p.sensei_program is not null and p.sensei_program = (@ProgUID)  and i.sensei_includeinpsr = 1