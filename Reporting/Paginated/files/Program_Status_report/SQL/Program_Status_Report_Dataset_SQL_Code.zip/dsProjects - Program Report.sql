Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProgUID varchar(50)
set @ProgUID = '6843E465-B752-EF11-BFE3-000D3AE1A88F'

SELECT
	Pj.[sensei_projectid] as [Project Id]
	,Pj.[sensei_program] as [Program Id]
	,Pj.[sensei_name] AS [Project Name]
	,Project_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_project&id=',[sensei_projectid]) 
	,St.[sensei_stageentered] AS [Project_Phase]
	,Pj.[sensei_projectmanagername] AS [Project Manager]
	,Pj.[sensei_sponsorname] AS [Sponsor]
	,(Pj.[sensei_percentcomplete] / 100.0) AS [Percent Complete]
	,Pj.[sensei_projectstart] AS [Start Date]
	,Pj.[sensei_targetfinish] AS [Target Finish]
	,Pj.[sensei_projectfinish] AS [Scheduled Finish]
	,Pj.[sensei_investmentcategoryname] AS [Investment Category]
	,Pj.[sensei_departmentname] AS [Department]
	,Pj.[sensei_efforttotal] as [Effort Total]
	,Pj.[sensei_effortcompleted] as [Effort Completed]
	,Pj.[sensei_location] as [Location]
	,Pj.[sensei_returnoninvestment] as [ROI]
	,(Pj.[sensei_efforttotal] - Pj.[sensei_effortcompleted]) as [Effort Remaining]
	,Pj.sensei_portfolioname AS [Portfolio Name]
	,Pj.sensei_programname AS [Program Name]
	,Pj.statuscodename as [Status]
	,Pj.sensei_baselinestart as [Baseline Start Date]
	,Pj.sensei_baselinefinish as [Baseline Finish Date]
	,Pj.sensei_baselineefforttotal as [Baseline Effort]
	,Pj.sensei_baselinedurationweekdays as [Baseline Duration]
	,Pj.sensei_effortvariance as [Baseline Effort Variance]
	,Pj.sensei_finishvariance as [Baseline Finish Variance]

  FROM [dbo].[sensei_project] as Pj
	left join (SELECT 
					RankedEntries.[sensei_primaryentityid],
					RankedEntries.[sensei_stageentered]
				FROM (
					SELECT 
						Bp.[sensei_primaryentityid],
						Bp.[sensei_stageentered],
						ROW_NUMBER() OVER (
							PARTITION BY [sensei_primaryentityid] 
							ORDER BY [sensei_dateentered] DESC
						) as rn
					FROM [dbo].[sensei_businessprocessflowlog] as Bp
					WHERE [sensei_primaryentity] = 'sensei_project'
				) AS RankedEntries
				WHERE rn = 1) AS St
				on Pj.[sensei_projectid] = St.[sensei_primaryentityid]

	CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
WHERE Pj.[sensei_program] IN (@ProgUID)
ORDER BY Pj.[sensei_name] 