--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'

SELECT 
    p.sensei_program AS [Project Program Id],
    p.sensei_name AS [Project Name],
    dc.sensei_program as [Program Id],
    dc.sensei_programname as [Program Name],
    dc.sensei_decisionid as [Decision Id],
    dc.sensei_name AS [Decision Name],
    dc.sensei_description as [Description],
    dc.statuscodename as [Status],
    dc.sensei_priorityname as [Priority],
    dc.sensei_duedate as [Due Date],
    dc.sensei_categoryname as [Category],
    dc.sensei_escalationrequiredname as [Escalation Required],
    dc.sensei_escalationmanagername as [Escalation Manager],
    dc.sensei_decisiondate as [Decision Date],
    dc.sensei_approvername as [Approver],
    dc.sensei_assignedtoname  as [Assigned To],
    CASE 
        WHEN dc.statuscodename <> 'Active' then 0
        WHEN dc.sensei_duedate < Getdate() then 4 
        WHEN dc.sensei_duedate is null then 3 
        ELSE 1 
    END AS StatusKPI,

    CASE 
        WHEN dc.statuscodename <> 'Active' then 'Completed'
        WHEN dc.sensei_duedate < Getdate() then 'Overdue' 
        WHEN dc.sensei_duedate is null then 'Due Date Missing'
        ELSE 'On Track' 
    END AS StatusKPITooltip,

    dc.[sensei_includeinprogramreportname] as [Include in Program Report],
    dc.[sensei_includeinpsrname] as [Include in PSR],
    Decisions_URL = CONCAT('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_decision&id=',dc.sensei_decisionid)

FROM [dbo].[sensei_decision] dc
    LEFT JOIN (SELECT sensei_projectid, sensei_program, sensei_name FROM dbo.sensei_project) p ON p.sensei_projectid = dc.sensei_project 
    CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

WHERE p.sensei_program IS NOT NULL
    AND p.sensei_program = (@ProgUID)
 and dc.sensei_includeinpsr = 1