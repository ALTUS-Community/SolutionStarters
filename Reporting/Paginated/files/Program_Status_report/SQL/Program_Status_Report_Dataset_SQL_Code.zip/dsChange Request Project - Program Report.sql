--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'

SELECT 
    p.sensei_program AS [Project Program Id],
    p.sensei_name as [Project Name], 
    c.sensei_program as [Program Id],
    c.sensei_programname as [Program Name],
    c.sensei_changerequestid as [Change Request Id],
    c.sensei_name AS [Change Request Name],
    c.sensei_description as [Description],
    c.sensei_drivenbyname as [Driven by],
    c.sensei_implementationdate as [Implementation Date],
    c.sensei_categoryname as [Category],
    c.sensei_priorityname as [Priority],
    c.sensei_assignedtoname as [Assigned To],
    c.sensei_workeffortestimate as [Work Effort Estimate],
    c.sensei_workeffortdetails as [Work Effort Details],
    c.sensei_costestimate as [Cost Estimate],
    c.sensei_costestimatedetails as [Cost Estimate Details],
    c.sensei_durationestimate as [Duration Estimate],
    c.sensei_durationestimatedetails as [Duration Estimate Details],
    c.sensei_resourceimpacts as [Resource Impacts],
    c.sensei_impactonotherprojects as [Impact on Other Projects],
    c.sensei_assumptions as [Assumptions],
    c.sensei_approvedrejectedbyname as [Approved Rejected By],
    c.sensei_approvedrejecteddate as [Approved Rejected Date],
    c.sensei_duedate as [Due Date],
    c.statuscodename as [Status],
    CASE 
        WHEN c.statuscodename = 'Approved' then 0
        WHEN c.statuscodename = 'Rejected' then 0
        WHEN c.statuscodename = 'On Hold' then 2
        WHEN c.sensei_duedate < Getdate() then 4 
        WHEN c.sensei_duedate is null then 3 
        ELSE 1 
    END AS StatusKPI,

    CASE 
        WHEN c.statuscodename = 'Approved' then 'Completed'
        WHEN c.statuscodename = 'Rejected' then 'Completed'
        WHEN c.statuscodename = 'On Hold' then 'On Hold'
        WHEN c.sensei_duedate < Getdate() then 'Overdue'  
        WHEN c.sensei_duedate is null then 'Due Date Missing'
        ELSE 'On Track' 
    END AS StatusKPITooltip,

    c.[sensei_includeinprogramreportname] as [Include in Program Report],
    c.[sensei_includeinpsrname] as [Include in PSR],
    Changes_URL = CONCAT('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_changerequest&id=',c.sensei_changerequestid)

FROM [dbo].[sensei_changerequest] c
    LEFT JOIN (SELECT sensei_projectid, sensei_program, sensei_name FROM dbo.sensei_project) p ON p.sensei_projectid = c.sensei_project 
    CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

WHERE p.sensei_program IS NOT NULL
    AND p.sensei_program = (@ProgUID)
 and c.sensei_includeinpsr = 1