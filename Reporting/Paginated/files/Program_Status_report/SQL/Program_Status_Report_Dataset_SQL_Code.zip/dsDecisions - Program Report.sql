Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProgUID varchar(50)
set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'


SELECT 
dc.sensei_program as [Program Id],
dc.sensei_programname as [Program Name],
dc.sensei_decisionid as [Decision Id],
dc.sensei_name as [Decision Name],
dc.sensei_description as [Description],
dc.statuscodename as [Status],
dc.sensei_priorityname as [Priority],
dc.sensei_duedate as [Due Date],
dc.sensei_categoryname as [Category],
dc.sensei_escalationrequiredname as [Escalation Required],
dc.sensei_escalationmanagername as [Escalation Manager],
dc.sensei_decisiondate as [Decision Date],
dc.sensei_approvername as [Approver],
dc.sensei_assignedtoname as [Assigned To],
case 
	when dc.statuscodename <> 'Active' then 0
	when dc.sensei_duedate < Getdate() then 4 
    when dc.sensei_duedate is null then 3 
	else 1 
	end as StatusKPI,

case 
	when dc.statuscodename <> 'Active' then 'Completed'
	when dc.sensei_duedate < Getdate() then 'Overdue' 
    when dc.sensei_duedate is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,

dc.[sensei_includeinprogramreportname] as [Include in Program Report],
dc.[sensei_includeinpsrname] as [Include in PSR],
Decisions_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_decision&id=',dc.sensei_decisionid)


 FROM [dbo].[sensei_decision] dc
 CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
 
 where dc.sensei_program is not null
      and dc.sensei_program = (@ProgUID)
and dc.sensei_includeinprogramreport = 1