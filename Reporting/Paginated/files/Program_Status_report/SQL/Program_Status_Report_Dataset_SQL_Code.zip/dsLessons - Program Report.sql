--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'

SELECT 
	l.sensei_program as [Program Id],
	l.sensei_programname as [Program Name],
	l.sensei_lessonlearnedid as [Lesson Learned Id],
	l.sensei_name as [Lesson Learned Name],
	l.sensei_categoryname as [Category],
	l.statuscodename  as [Status],
	l.sensei_observation as [Observation],
	l.sensei_recommendation as [Recommendation],
	l.sensei_lessonlearned as [Lesson Learned],
	l.sensei_actiontaken as [Action Taken],
	l.[sensei_includeinprogramreportname] as [Include in Program Report],
	l.[sensei_includeinpsrname] as [Include in PSR],

	Lessons_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_lessonlearned&id=',l.sensei_lessonlearnedid)


 FROM [dbo].[sensei_lessonlearned] l
 CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

 where l.sensei_program is not null
     and l.sensei_program = (@ProgUID)
and l.sensei_includeinprogramreport = 1