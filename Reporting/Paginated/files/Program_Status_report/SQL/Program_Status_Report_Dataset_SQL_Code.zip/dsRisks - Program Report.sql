--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'


SELECT 

r.sensei_program as [Program Id],
r.sensei_programname as [Program Name],
r.sensei_riskid as [Risk Id],
r.sensei_name as [Risk Name],
r.sensei_assignedtoyominame as [Assigned To],
r.sensei_riskownername as [Risk Owner] ,
r.sensei_categoryname as [Category],
r.statuscodename as [Status],
r.sensei_likelihoodname as [Likelihood],
r.sensei_consequencename as [Consequence],
r.sensei_riskscore as [Risk Score],
concat(right(r.sensei_likelihood,1),right(r.sensei_consequence,1)) as [RiskMatrixScore],
r.sensei_cost as [Cost],
r.sensei_description as [Description],
r.sensei_mitigationplan as [Mitigation Plan],
r.sensei_contingencyplan as [Contigency Plan],
r.sensei_triggerdescription as [Trigger Description],
r.sensei_triggername as [Trigger],
r.sensei_duedate as [Due Date],
case 
	when r.statuscodename = 'Postponed' then 2
	when r.statuscodename <> 'Active' then 0
	when r.sensei_duedate < Getdate() then 4 
    when r.sensei_duedate is null then 3 
	else 1 
	end as StatusKPI,

case 
	when r.statuscodename = 'Postponed' then 'Postponed'
	when r.statuscodename <> 'Active' then 'Completed'
	when r.sensei_duedate < Getdate() then 'Overdue' 
    when r.sensei_duedate is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,

r.[sensei_includeinprogramreportname] as [Include in Program Report],
r.[sensei_includeinpsrname] as [Include in PSR],
Risk_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_risk&id=',r.sensei_riskid)

FROM [dbo].[sensei_risk] r  
CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

where r.sensei_program is not null
 and r.sensei_program = (@ProgUID)
and r.sensei_includeinprogramreport = 1