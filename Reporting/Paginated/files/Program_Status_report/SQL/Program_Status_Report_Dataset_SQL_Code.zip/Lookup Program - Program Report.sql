SELECT [sensei_programid] as [Program Id]
      ,[sensei_name] AS [Program Name]
  FROM [dbo].[sensei_program]
  ORDER BY [sensei_name]