--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProgUID varchar(50)
--set @ProgUID = '5E2670DE-608A-EA11-A811-000D3A31A6EE'


SELECT
       [sensei_programid] as [Program Id]
      ,[sensei_name] as [Program Name]
      ,[owneridname] as [OwnerId Name]
      ,[sensei_departmentname] as [Department]
      ,[sensei_startdate] as [Start Date]
      ,[sensei_finishdate] as [Finish Date]
      ,[sensei_project_durationsum_date] as [Project Durationsum Date]
	  ,[sensei_investmentcategoryname] as [Investment Category]
      ,[sensei_location] as [Location]
	  ,[sensei_portfolio] as [Portfolio Id]
	  ,[sensei_portfolioname] as [Portfolio Name]
      ,[sensei_problemstatement] as [Problem Statement]
      ,[sensei_sponsorname] as [Sponsor]
	  ,[sensei_project_durationcompletedsum] as [Duration Completed Sum]
      ,[sensei_project_durationcompletedsum_date] as [Duration Completed Sum Date]
      ,[sensei_project_durationsum] as [Duration_Sum]
	  ,[sensei_project_effort] as [Effort]
      ,[sensei_project_effort_date] as [Effort Date]
      ,[sensei_project_effortcompleted] as [Effort Completed]
      ,[sensei_project_effortcompleted_date] as [Effort Completed Date]
      ,[sensei_project_progress] as [Project Progress]
	  ,[sensei_project_effort] - [sensei_project_effortcompleted] as [Effort Remaining]
  FROM [dbo].[sensei_program]
  WHERE [sensei_programid] = @ProgUID