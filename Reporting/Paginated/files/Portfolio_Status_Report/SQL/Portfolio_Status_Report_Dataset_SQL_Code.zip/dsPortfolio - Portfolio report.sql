--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @PortUID varchar(50)
--set @PortUID = 'B3442B8B-598A-EA11-A811-000D3A31A6EE'

SELECT
       [sensei_portfolioid] as [Portfolio_Id],
       [sensei_name] as [Portfolio Name],
       [owneridname] as [OwnerId name],
       [sensei_departmentname] as [Department],
       [sensei_description] as [Description],
       [sensei_investmentcategoryname] as [Investment Category],
       [sensei_location] as [Location],
       [sensei_sponsorname] as [Sponsor],
	   [statuscodename] as [Status],
       [sensei_justification] as [Justification],
       [sensei_vision] as [Vision],
       [sensei_scope] as [Scope],
       [sensei_benefitsstrategy] as [Benefits Strategy],
       [sensei_resourcesneeded] as [Resources Needed],
       [sensei_stakeholderconsiderations] as [Stakeholder Considerations],
       [sensei_project_effort] as [Portfolio Effort],
       [sensei_project_effort_date] as [Portfolio Effort Date],
       [sensei_project_effortcompleted] as [Portfolio Effort Completed],
       [sensei_project_effortcompleted_date] as [Portfolio Effort Completed Date],
       [sensei_project_progress] as [Portfolio Percent Complete],
       [sensei_project_effort] - [sensei_project_effortcompleted] AS [Effort Remaining]
FROM 
       [dbo].[sensei_portfolio]
WHERE 
       [sensei_portfolioid] = @PortUID;