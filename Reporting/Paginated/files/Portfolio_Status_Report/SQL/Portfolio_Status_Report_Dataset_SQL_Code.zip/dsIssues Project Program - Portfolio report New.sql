--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @PortUID varchar(50)
--set @PortUID = 'BD146843-B452-EF11-BFE3-000D3AE1A88F'

SELECT 	
		CASE WHEN p.sensei_name IS NULL
			 THEN COALESCE( p.sensei_name, CONCAT('Program: ', i.sensei_programname), CONCAT('Program: ', pr.sensei_name)) 
			 ELSE COALESCE( i.sensei_programname,CONCAT('Project: ', i.sensei_projectname), CONCAT('Project: ', p.sensei_name)) 
			 END AS [Project Or ProgramName],
		CASE
			WHEN p.sensei_name IS NOT NULL THEN 1
			ELSE 0
		END AS [IsProject],

		i.sensei_issueid as [Issue Id],
		i.sensei_name AS [Issue Name],
		i.sensei_assignedtoname as [Assigned To],
		i.statuscodename as [Status],
		i.sensei_categoryname as [Category],
		i.sensei_priorityname as [Priority],
		i.sensei_duedate as [Due Date],
		i.sensei_description as [Description],
		i.sensei_resolution as [Resolution],
		i.sensei_linkedtorisk as [Linked To Risk ID],
		i.sensei_linkedtoriskname as [Linked To Risk Name],
    
		CASE 
			WHEN i.statuscodename = 'Postponed' THEN 2
			WHEN i.statuscodename <> 'Active' THEN 0
			WHEN i.sensei_duedate < GETDATE() THEN 4 
			WHEN i.sensei_duedate IS NULL THEN 3 
			ELSE 1 
		END AS StatusKPI,

		CASE 
			WHEN i.statuscodename = 'Postponed' THEN 'Postponed'
			WHEN i.statuscodename <> 'Active' THEN 'Completed'
			WHEN i.sensei_duedate < GETDATE() THEN 'Overdue' 
			WHEN i.sensei_duedate IS NULL THEN 'Due Date Missing'
			ELSE 'On Track' 
		END AS StatusKPITooltip,

		i.[sensei_includeinprogramreportname] as [Include in Program Report],
		i.[sensei_includeinpsrname] as [Include in PSR],
		CONCAT('https://', @EnvironmentURL, '.dynamics.com/main.aspx?appid=', app.appmoduleid, '&pagetype=entityrecord&etn=sensei_issue&id=', i.sensei_issueid) AS Issue_URL

 FROM   [dbo].[sensei_issue] i 
		LEFT JOIN (SELECT sensei_projectid, sensei_name, sensei_program, sensei_reportingportfolioname, sensei_reportingportfolio FROM dbo.sensei_project WHERE sensei_reportingportfolio = @PortUID) AS p ON p.sensei_projectid = i.sensei_project 
		LEFT JOIN (SELECT sensei_programid, sensei_name, sensei_portfolioname, sensei_portfolio FROM dbo.sensei_program WHERE sensei_portfolio = @PortUID ) pr ON pr.sensei_programid = ISNULL(i.sensei_program, p.sensei_program)
	    CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
WHERE 	(p.sensei_reportingportfolio = @PortUID OR pr.sensei_portfolio = @PortUID)
		AND (i.[sensei_includeinpsr]=1 OR i.[sensei_includeinprogramreport] = 1)
ORDER BY IsProject, COALESCE( p.sensei_name, CONCAT('Program: ', i.sensei_programname), CONCAT('Program: ', pr.sensei_name))