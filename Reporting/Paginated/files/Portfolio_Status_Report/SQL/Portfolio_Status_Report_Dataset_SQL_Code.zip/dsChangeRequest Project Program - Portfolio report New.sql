--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @PortUID varchar(50)
--set @PortUID = 'BD146843-B452-EF11-BFE3-000D3AE1A88F'

 SELECT	p.sensei_name AS [Project Name],
		c.sensei_portfolio as [Portfolio Id],
		c.sensei_portfolioname as [Portfolio Name],
		c.sensei_changerequestid as [Change Request Id],
		c.sensei_name AS [Change Request Name],
		c.sensei_description as [Description],
		c.sensei_drivenbyname as [Driven by],
		c.sensei_implementationdate as [Implementation Date],
		c.sensei_categoryname as [Category],
		c.sensei_priorityname as [Priority],
		c.sensei_assignedtoname as [Assigned To],
		c.sensei_workeffortestimate as [Work Effort Estimate],
		c.sensei_workeffortdetails as [Work Effort Details],
		c.sensei_costestimate as [Cost Estimate],
		c.sensei_costestimatedetails as [Cost Estimate Details],
		c.sensei_durationestimate as [Duration Estimate],
		c.sensei_durationestimatedetails as [Duration Estimate Details],
		c.sensei_resourceimpacts as [Resource Impacts],
		c.sensei_impactonotherprojects as [Impact on Other Projects],
		c.sensei_assumptions as [Assumptions],
		c.sensei_approvedrejectedbyname as [Approved Rejected By],
		c.sensei_approvedrejecteddate as [Approved Rejected Date],
		c.sensei_duedate as [Due Date],
		c.statuscodename as [Status],

		CASE 
			WHEN c.statuscodename IN ('Approved', 'Rejected') THEN 0
			WHEN c.statuscodename = 'On Hold' THEN 2
			WHEN c.sensei_duedate < GETDATE() THEN 4 
			WHEN c.sensei_duedate IS NULL THEN 3 
			ELSE 1 
		END AS StatusKPI,

		CASE 
			WHEN c.statuscodename IN ('Approved', 'Rejected') THEN 'Completed'
			WHEN c.statuscodename = 'On Hold' THEN 'On Hold'
			WHEN c.sensei_duedate < GETDATE() THEN 'Overdue'  
			WHEN c.sensei_duedate IS NULL THEN 'Due Date Missing'
			ELSE 'On Track' 
		END AS StatusKPITooltip,

		c.[sensei_includeinprogramreportname] as [Include in Program Report],
		c.[sensei_includeinpsrname] as [Include in PSR],
		Changes_URL = CONCAT('https://', @EnvironmentURL, '.dynamics.com/main.aspx?appid=', app.appmoduleid, '&pagetype=entityrecord&etn=sensei_changerequest&id=', c.sensei_changerequestid),

		CASE WHEN p.sensei_name IS NULL
			 THEN COALESCE( p.sensei_name, CONCAT('Program: ', c.sensei_programname), CONCAT('Program: ', pr.sensei_name)) 
			 ELSE COALESCE( c.sensei_programname,CONCAT('Project: ', c.sensei_projectname), CONCAT('Project: ', p.sensei_name)) 
			 END AS [Project Or ProgramName],
		CASE
			WHEN p.sensei_name IS NOT NULL THEN 1
			ELSE 0
		END AS IsProject

 FROM	[dbo].[sensei_changerequest] c
		LEFT JOIN (SELECT sensei_projectid, sensei_name, sensei_program, sensei_reportingportfolioname, sensei_reportingportfolio FROM dbo.sensei_project WHERE sensei_reportingportfolio = @PortUID) AS p ON p.sensei_projectid = c.sensei_project 
		LEFT JOIN (SELECT sensei_programid, sensei_name, sensei_portfolioname, sensei_portfolio FROM dbo.sensei_program WHERE sensei_portfolio = @PortUID ) pr ON pr.sensei_programid = ISNULL(c.sensei_program, p.sensei_program)
	    CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
WHERE 
	(p.sensei_reportingportfolio = @PortUID OR pr.sensei_portfolio = @PortUID)
	AND	(c.[sensei_includeinpsr]=1 OR c.[sensei_includeinprogramreport] = 1)

ORDER BY IsProject, COALESCE( p.sensei_name, CONCAT('Program: ', c.sensei_programname), CONCAT('Program: ', pr.sensei_name))