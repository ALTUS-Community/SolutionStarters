--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @PortUID varchar(50)
--set @PortUID = 'B3442B8B-598A-EA11-A811-000D3A31A6EE'


SELECT 
k.sensei_portfolio as [Portfolio Id],
k.sensei_portfolioname as [Portfolio Name],
k.sensei_keydateid as [KeyDate Id],
k.sensei_name as [Key Date Name],
k.sensei_date as [Date],
k.sensei_description as [Description],
k.statuscodename as [Status],
case 
	when k.statuscodename = 'Done' then 0
	when k.sensei_date < Getdate() then 4 
    when k.sensei_date is null then 3 
	else 1 
	end as StatusKPI,

case
	when k.statuscodename = 'Done' then 'Completed'
	when k.sensei_date < Getdate() then 'Overdue' 
    when k.sensei_date is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,

KeyDate_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_keydate&id=',k.sensei_keydateid)


FROM [dbo].[sensei_keydate] k
	CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

WHERE k.sensei_portfolio is not null
   and sensei_portfolio = (@PortUID)