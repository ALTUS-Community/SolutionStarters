Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @PortUID varchar(50)
set @PortUID = '26B168C2-5B71-EF11-A671-000D3AE071FE'

 SELECT	r.sensei_portfolio as [Portfolio Id],
		r.sensei_portfolioname as [Portfolio Name],
		r.sensei_riskid as [Risk Id],
		r.sensei_name AS [Risk Name],
		r.sensei_assignedtoyominame as [Assigned To],
		r.sensei_riskownername as [Risk Owner],
		r.sensei_categoryname as [Category],
		r.statuscodename as [Status],
		r.sensei_likelihoodname as [Likelihood],
		r.sensei_consequencename as [Consequence],
		r.sensei_riskscore as [Risk Score],
		CONCAT(RIGHT(r.sensei_likelihood,1),RIGHT(r.sensei_consequence,1)) AS RiskMatrixScore,
		r.sensei_cost as [Cost],
		r.sensei_description as [Description],
		r.sensei_mitigationplan as [Mitigation Plan],
		r.sensei_contingencyplan as [Contigency Plan],
		r.sensei_triggerdescription as [Trigger Description],
		r.sensei_triggername as [Trigger],
		r.sensei_duedate as [Due Date],
		CASE 
			WHEN r.statuscodename = 'Postponed' THEN 2
			WHEN r.statuscodename <> 'Active' THEN 0
			WHEN r.sensei_duedate < GETDATE() THEN 4 
			WHEN r.sensei_duedate IS NULL THEN 3 
			ELSE 1 
		END AS StatusKPI,

		CASE 
			WHEN r.statuscodename = 'Postponed' THEN 'Postponed'
			WHEN r.statuscodename <> 'Active' THEN 'Completed'
			WHEN r.sensei_duedate < GETDATE() THEN 'Overdue' 
			WHEN r.sensei_duedate IS NULL THEN 'Due Date Missing'
			ELSE 'On Track' 
		END AS StatusKPITooltip,

		r.[sensei_includeinprogramreportname] as [Include in Program Report],
		r.[sensei_includeinpsrname] as [Include in PSR],
		CONCAT('https://', @EnvironmentURL, '.dynamics.com/main.aspx?appid=', app.appmoduleid, '&pagetype=entityrecord&etn=sensei_risk&id=', r.sensei_riskid) AS Risk_URL,

		CASE WHEN p.sensei_name IS NULL
			 THEN COALESCE( p.sensei_name, CONCAT('Program: ', r.sensei_programname), CONCAT('Program: ', pr.sensei_name)) 
			 ELSE COALESCE( r.sensei_programname,CONCAT('Project: ', r.sensei_projectname), CONCAT('Project: ', p.sensei_name)) 
			 END AS [Project Or ProgramName],
		
		CASE
			WHEN p.sensei_name IS NOT NULL THEN 1
			ELSE 0
		END AS IsProject

   FROM [dbo].[sensei_risk] r  
		LEFT JOIN (SELECT sensei_projectid, sensei_name, sensei_program, sensei_reportingportfolioname, sensei_reportingportfolio FROM dbo.sensei_project WHERE sensei_reportingportfolio = @PortUID) AS p ON p.sensei_projectid = r.sensei_project 
		LEFT JOIN (SELECT sensei_programid, sensei_name, sensei_portfolioname, sensei_portfolio FROM dbo.sensei_program WHERE sensei_portfolio = @PortUID ) pr ON pr.sensei_programid = ISNULL(r.sensei_program, p.sensei_program)
        CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
WHERE 
	(p.sensei_reportingportfolio = @PortUID OR pr.sensei_portfolio = @PortUID)
	AND
	(r.[sensei_includeinpsr]=1 OR r.[sensei_includeinprogramreport] = 1)

ORDER BY IsProject, COALESCE( p.sensei_name, CONCAT('Program: ', r.sensei_programname), CONCAT('Program: ', pr.sensei_name))