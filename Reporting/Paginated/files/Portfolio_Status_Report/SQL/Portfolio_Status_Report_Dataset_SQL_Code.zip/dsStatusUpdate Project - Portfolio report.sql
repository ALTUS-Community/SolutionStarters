--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @PortUID varchar(50)
--set @PortUID = 'BD146843-B452-EF11-BFE3-000D3AE1A88F'

SELECT * FROM (
				  SELECT 
				  		 P.ProjectName as [Project Name]
						,P.sensei_program AS [Project Program]
						,[sensei_project] as [Project Id]
						,sensei_statusdate as [Status Date]
						,[sensei_projectkpi] as [Project KPI]
						,[sensei_projectkpiname] as [Project KPI Name]
						,[sensei_projectstatus] as [Project Status]
						,[sensei_deliverableskpi] as [Deliverables KPI]
						,[sensei_deliverableskpiname] as [Deliverables KPI Name]
						,[sensei_deliverablesstatus] as [Deliverables Status]
						,[sensei_schedulekpi] as [Schedule KPI]
						,[sensei_schedulekpiname] as [Schedule KPI Name]
						,[sensei_schedulestatus] as [Schedule Status]
						,[sensei_financialskpi] as [Financials KPI]
						,[sensei_financialskpiname] as [Financials KPI Name]
						,[sensei_financialsstatus] as [Financials Status]
						,[sensei_workkpi] as [Work KPI] 
						,[sensei_workkpiname] as [Work KPI Name]
						,[sensei_workstatus] as [Work Status]
						,[sensei_issueskpi]  as [Issues KPI]
						,[sensei_issueskpiname] as [Issues KPI Name]
						,[sensei_issuesstatus] as [Issues Status]
						,[sensei_riskskpi] as [Risks KPI]
						,[sensei_riskskpiname]  as [Risks KPI Name]
						,[sensei_risksstatus] as [Risks Status]
      					,[sensei_changerequestskpi] as [Change Requests KPI]
						,[sensei_changerequestskpiname]  as [Change Requests KPI Name]
						,[sensei_changerequestsstatus] as [Change Requests Status]
						 ,ROW_NUMBER() OVER (
						  PARTITION BY sensei_project
						  ORDER BY sensei_statusdate DESC
						) AS ProjectRN,
						StatusUpdate_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_statusupdate&id=',SU.[sensei_statusupdateid])

                   FROM [dbo].[sensei_statusupdate] AS SU

						  RIGHT JOIN (
										SELECT 
											sensei_projectid, 
											sensei_program, 
											sensei_name AS ProjectName 
										FROM dbo.sensei_project 
										WHERE statuscode = 1 AND sensei_projectid IS NOT NULL AND sensei_reportingportfolio = @PortUID
									) AS P ON p.sensei_projectid = SU.sensei_project

						  CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

) AS SubQuery
WHERE ProjectRN = 1
ORDER BY [Project Name], [Status Date]