--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @PortUID varchar(50)
--set @PortUID = 'B3442B8B-598A-EA11-A811-000D3A31A6EE'

SELECT
    Pj.[sensei_projectid] as [Project Id],
    Pj.[sensei_program] as [Program Id],
    Pj.[sensei_programname] as [Program Name],
    Pj.[sensei_name] AS [Project Name],
    Project_URL = CONCAT('https://', @EnvironmentURL, '.dynamics.com/main.aspx?appid=', app.appmoduleid, '&pagetype=entityrecord&etn=sensei_project&id=', Pj.[sensei_projectid]),
    St.[sensei_stageentered] AS [Project_Phase],
    Pj.[sensei_projectmanagername] AS [Project Manager],
    Pj.[sensei_sponsorname] AS [Sponsor],
    (Pj.[sensei_percentcomplete] / 100.0) AS [Percent Complete],
    Pj.[sensei_projectstart] AS [Start Date],
    Pj.[sensei_targetfinish] AS [Target Finish Date],
    Pj.[sensei_projectfinish] AS [Scheduled Finish Date],
    Pj.[sensei_investmentcategoryname] AS [Investment Category],
    Pj.[sensei_departmentname] AS [Department],
    Pj.[sensei_efforttotal] as [Effort Total],
    Pj.[sensei_effortcompleted] as [Effort Completed],
    Pj.[sensei_location] as [Location],
    Pj.[sensei_returnoninvestment] as [ROI],
    (Pj.[sensei_efforttotal] - Pj.[sensei_effortcompleted]) AS [Effort Remaining],
    COALESCE(Pf.sensei_name, 
             (SELECT sensei_name FROM [dbo].[sensei_portfolio] WHERE sensei_portfolioid = Pj.[sensei_portfolio])) AS [Portfolio Name],
    Pj.statuscodename as [Status],
	Pj.sensei_baselinestart as [Baseline Start Date]
	,Pj.sensei_baselinefinish as [Baseline Finish Date]
	,Pj.sensei_baselineefforttotal as [Baseline Effort]
	,Pj.sensei_baselinedurationweekdays as [Baseline Duration]
	,Pj.sensei_effortvariance as [Baseline Effort Variance]
	,Pj.sensei_finishvariance as [Baseline Finish Variance]
    
    -- Combine Program Name and Portfolio Name
    ,COALESCE(Pr.sensei_name, Pf.sensei_name) AS [Project_Or_ProgramName] ,
	CASE WHEN pr.sensei_name IS NOT NULL
			 THEN COALESCE( pf.sensei_name, CONCAT('Program: ', pr.sensei_name)) 
			 ELSE CONCAT('Portfolio: ', pf.sensei_name)
			 END AS  [ProgramAndPortfolio]

FROM [dbo].[sensei_project] AS Pj
LEFT JOIN (
    SELECT 
        RankedEntries.[sensei_primaryentityid],
        RankedEntries.[sensei_stageentered]
    FROM (
        SELECT 
            Bp.[sensei_primaryentityid],
            Bp.[sensei_stageentered],
            ROW_NUMBER() OVER (PARTITION BY [sensei_primaryentityid] ORDER BY [sensei_dateentered] DESC) AS rn
        FROM [dbo].[sensei_businessprocessflowlog] AS Bp
        WHERE [sensei_primaryentity] = 'sensei_project'
    ) AS RankedEntries
    WHERE rn = 1
) AS St ON Pj.[sensei_projectid] = St.[sensei_primaryentityid]
CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
LEFT JOIN [dbo].[sensei_program] AS Pr ON Pj.[sensei_program] = Pr.[sensei_programid]
LEFT JOIN [dbo].[sensei_portfolio] AS Pf ON Pj.[sensei_portfolio] = Pf.[sensei_portfolioid]
WHERE Pf.[sensei_portfolioid] = @PortUID 
   OR Pj.[sensei_portfolio] = @PortUID
   OR Pj.[sensei_program] IN (
       SELECT [sensei_programid]
       FROM [dbo].[sensei_program]
       WHERE [sensei_portfolio] = @PortUID
   );