--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @PortUID varchar(50)
--set @PortUID = 'BD146843-B452-EF11-BFE3-000D3AE1A88F'


 SELECT	p.sensei_name AS [Project Name],
		dc.sensei_portfolio as [Portfolio Id],
		dc.sensei_portfolioname as [Portfolio Name],
		dc.sensei_decisionid as [Decision Id],
		dc.sensei_name AS [Decision Name],
		dc.sensei_description as [Description],
		dc.statuscodename as [Status],
		dc.sensei_priorityname as [Priority],
		dc.sensei_duedate as [Due Date],
		dc.sensei_categoryname as [Category],
		dc.sensei_escalationrequiredname as [Escalation Required],
		dc.sensei_escalationmanagername as [Escalation Manager],
		dc.sensei_decisiondate as [Decision Date],
		dc.sensei_approvername as [Approver],
		dc.sensei_assignedtoname as [Assigned To],
    
		CASE 
			WHEN dc.statuscodename <> 'Active' THEN 0
			WHEN dc.sensei_duedate < GETDATE() THEN 4 
			WHEN dc.sensei_duedate IS NULL THEN 3 
			ELSE 1 
		END AS StatusKPI,
    
		CASE 
			WHEN dc.statuscodename <> 'Active' THEN 'Completed'
			WHEN dc.sensei_duedate < GETDATE() THEN 'Overdue' 
			WHEN dc.sensei_duedate IS NULL THEN 'Due Date Missing'
			ELSE 'On Track' 
		END AS StatusKPITooltip,
    
		dc.[sensei_includeinprogramreportname] as [Include in Program Report],
		dc.[sensei_includeinpsrname] as [Include in PSR],
		Decisions_URL = CONCAT('https://', @EnvironmentURL, '.dynamics.com/main.aspx?appid=', app.appmoduleid, '&pagetype=entityrecord&etn=sensei_decision&id=', dc.sensei_decisionid),
    
		CASE WHEN p.sensei_name IS NULL
			 THEN COALESCE( p.sensei_name, CONCAT('Program: ', dc.sensei_programname), CONCAT('Program: ', pr.sensei_name)) 
			 ELSE COALESCE( dc.sensei_programname,CONCAT('Project: ', dc.sensei_projectname), CONCAT('Project: ', p.sensei_name)) 
			 END AS [Project Or ProgramName],
		CASE
			WHEN p.sensei_name IS NOT NULL THEN 1
			ELSE 0
		END AS IsProject

 FROM	[dbo].[sensei_decision] dc
		LEFT JOIN (SELECT sensei_projectid, sensei_name, sensei_program, sensei_reportingportfolioname, sensei_reportingportfolio FROM dbo.sensei_project WHERE sensei_reportingportfolio = @PortUID) AS p ON p.sensei_projectid = dc.sensei_project 
		LEFT JOIN (SELECT sensei_programid, sensei_name, sensei_portfolioname, sensei_portfolio FROM dbo.sensei_program WHERE sensei_portfolio = @PortUID ) pr ON pr.sensei_programid = ISNULL(dc.sensei_program, p.sensei_program)
		CROSS JOIN (SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
WHERE 
		(p.sensei_reportingportfolio = @PortUID OR pr.sensei_portfolio = @PortUID)
		AND (dc.[sensei_includeinpsr]=1 OR dc.[sensei_includeinprogramreport] = 1)

ORDER BY IsProject, COALESCE( p.sensei_name, CONCAT('Program: ', dc.sensei_programname), CONCAT('Program: ', pr.sensei_name))