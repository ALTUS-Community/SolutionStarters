SELECT [sensei_portfolioid] as [Portfolio_Id],
       [sensei_name] AS [Portfolio Name]
  FROM [dbo].[sensei_portfolio]
  ORDER BY [sensei_name]