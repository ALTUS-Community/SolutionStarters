Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '9946E29F-EAAC-4F63-90F7-473695100ED4'


SELECT 
l.sensei_project as [Project Id],
l.sensei_projectname as [Project Name],
l.sensei_lessonlearnedid as [Lesson Learned Id],
l.sensei_name as [Lesson Learned Name],
l.sensei_categoryname as [Category],
l.statuscodename as [Status],
l.sensei_observation as [Observation],
l.sensei_recommendation as [Recommendation],
l.sensei_lessonlearned as [Lesson Learned],
l.sensei_actiontaken as [Action Taken],
l.[sensei_includeinprogramreportname] as [Include in Program Report],
l.[sensei_includeinpsrname] as [Include in PSR],
Lessons_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_lessonlearned&id=',l.sensei_lessonlearnedid),

CASE 
    WHEN statuscode = 1 THEN 1
    ELSE NULL
END AS ActiveStatus,
CASE 
    WHEN statuscode = 955000001 THEN 1
    ELSE NULL
END AS ClosedStatus
FROM [dbo].[sensei_lessonlearned] l
           CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
WHERE l.sensei_project is not null
      and l.sensei_project = (@ProjUID)
      and l.sensei_includeinpsr = 1