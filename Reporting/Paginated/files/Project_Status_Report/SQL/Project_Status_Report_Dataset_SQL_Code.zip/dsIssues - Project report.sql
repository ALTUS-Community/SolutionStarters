Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '9946E29F-EAAC-4F63-90F7-473695100ED4'


SELECT 

i.sensei_project as [Project Id],
i.sensei_projectname as [Project Name],
i.sensei_issueid [Issue Id],
i.sensei_name as [Issue Name],
i.sensei_assignedtoname as [Assigned To],
i.statuscodename as [Status],
i.sensei_categoryname as [Category],
i.sensei_priorityname as [Priority],
i.sensei_duedate as [Due Date],
i.sensei_description as [Description],
i.sensei_resolution as [Resolution],
i.sensei_linkedtorisk as [Linked To Risk ID],
i.sensei_linkedtoriskname as [Linked To Risk Name],
case 
	when i.statuscodename = 'Postponed' then 2
    when i.statuscodename <> 'Active' then 0
	when i.sensei_duedate < Getdate() then 4 
        when i.sensei_duedate is null then 3 
	else 1 
	end as StatusKPI,

case 
	when i.statuscodename = 'Postponed' then 'Postponed'
	when i.statuscodename <> 'Active' then 'Completed'
	when i.sensei_duedate < Getdate() then 'Overdue' 
    when i.sensei_duedate is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,

i.[sensei_includeinprogramreportname] as [Include in Program Report],
i.[sensei_includeinpsrname] as [Include in PSR] ,
Issue_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_issue&id=',i.sensei_issueid)


 FROM [dbo].[sensei_issue] i 
 CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
 where i.sensei_project is not null and i.sensei_includeinpsr = 1 and i.sensei_project = (@ProjUID)