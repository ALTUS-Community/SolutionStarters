
                 Select trans.createdon as [Created On],
						trans.currencyname as [Currency Name],
						trans.currencyprecision as [Currency Precision],
						trans.currencysymbol as [Currency Symbol],
						trans.exchangerate as [Exchange Rate],
						trans.isocurrencycode as [ISO CurrencyCode],
						trans.statuscodename as [Status],
						trans.transactioncurrencyid as [Transaction Currency Id]
				   from transactioncurrency trans inner join organization org on trans.transactioncurrencyid = org.basecurrencyid 
                   where trans.exchangerate = 1.0 

