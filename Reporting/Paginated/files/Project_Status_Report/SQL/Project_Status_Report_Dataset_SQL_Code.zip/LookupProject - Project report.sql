

   SELECT [sensei_projectid] as [Project Id],
          [sensei_name] AS [Project Name]
     FROM [dbo].[sensei_project]
 ORDER BY [sensei_name]