Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '1C4CF6C1-B28A-41DD-BF95-BB20446469C5'

SELECT t.[sensei_project] as [Project Id],
	   t.[sensei_taskid] as [Task Id],
	   t.[sensei_name] as [Task Name],
	   t.[sensei_categoryname] as [Category],
       t.[sensei_duedate] as [Due Date],
	   t.[sensei_notes] as [Notes],
	   t.[sensei_summaryname] as [Summary Task],
	   t.[sensei_milestonename] as [Milestone],
	   t.[sensei_taskstart] as [Task Start],
	   t.[sensei_duration] as [Duration],
	   t.[sensei_taskfinish] as [Task Finish],
	   t.[sensei_effort] as [Effort],
	   t.[sensei_effortcompleted] as [Effort Completed],
	   t.[sensei_effortremaining] as [Effort Remaining],
	   t.[sensei_percentcomplete] as [Percent Complete],
	   t.[sensei_level] as [Task Level],
	   t.[sensei_sprintname] as [Sprint Name],
	   t.[sensei_bucketname] as [Bucket Name],
	   t.[sensei_size] as [Size],
  CASE 
	  WHEN t.sensei_percentcomplete >= '100' then 0
	  WHEN t.sensei_taskfinish < Getdate() then 4 
      WHEN t.sensei_taskfinish is null then 3
	  ELSE 1 
  END as StatusKPI,

  CASE 
	  WHEN t.sensei_percentcomplete >= '100' then 'Completed'
	  WHEN t.sensei_taskfinish < Getdate() then 'Overdue'  
      WHEN t.sensei_taskfinish is null then 'Due Date Missing'
	  ELSE 'On Track' 
  END as StatusKPITooltip,
p.sensei_name as [Project Name],
Milestone_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_task&id=',t.[sensei_taskid])
 FROM [dbo].[sensei_task] t
      CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
      LEFT JOIN dbo.sensei_project p ON p.sensei_projectid =t.sensei_project
WHERE t.sensei_project is not null
      and t.[sensei_milestonename]='Yes'
      and t.sensei_project = (@ProjUID)