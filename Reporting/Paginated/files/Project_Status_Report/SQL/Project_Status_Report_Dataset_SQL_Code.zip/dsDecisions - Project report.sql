Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '9946E29F-EAAC-4F63-90F7-473695100ED4'

SELECT 
dc.sensei_project as [Project Id],
dc.sensei_projectname as [Project Name],
dc.sensei_decisionid as [Decision Id],
dc.sensei_name as [Decision Name],
dc.sensei_description as [Description],
dc.statuscodename as [Status],
dc.sensei_priorityname as [Priority],
dc.sensei_duedate as [Due Date],
dc.sensei_categoryname as [Category],
dc.sensei_escalationrequiredname as [Escalation Required],
dc.sensei_escalationmanagername as [Escalation Manager],
dc.sensei_decisiondate as [Decision Date],
dc.sensei_approvername as [Approver],
dc.sensei_assignedtoname as [Assigned To],
case 
	when dc.statuscodename <> 'Active' then 0
	when dc.sensei_duedate < Getdate() then 4 
    when dc.sensei_duedate is null then 3 
	else 1 
	end as StatusKPI,

case 
	when dc.statuscodename <> 'Active' then 'Completed'
	when dc.sensei_duedate < Getdate() then 'Overdue' 
    when dc.sensei_duedate is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,

dc.[sensei_includeinprogramreportname] as [Include in Program Report],
dc.[sensei_includeinpsrname] as [Include in PSR],
Decisions_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_decision&id=',dc.sensei_decisionid)


 FROM [dbo].[sensei_decision] dc
 CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
 
 where dc.sensei_project is not null
      and dc.sensei_project = (@ProjUID)
 and dc.sensei_includeinpsr = 1