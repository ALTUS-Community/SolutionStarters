Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '442F9D2A-D84F-EF11-A316-000D3AE1A88F'

SELECT
      [sensei_financialtransactionid] as [Financial Transaction Id]
      ,f.[sensei_financialitem] as [Financial Item]
      ,f.[sensei_name] as [Financial Transaction Name]
      ,f.[sensei_type] as [Financial Type]
      ,f.[sensei_typename] as [Financial Type Name]
      ,f.[sensei_date] as [Financial Date]
,DATEADD(MONTH, DATEDIFF(MONTH, 0, f.[sensei_date]), 0) AS [FirstDateofMonth]
	  ,MONTH(f.[sensei_date]) as Month 
	  ,YEAR(f.[sensei_date]) as Year
	  ,(CAST(YEAR(f.[sensei_date]) as char(4)) + ' - ' + CAST(MONTH(f.[sensei_date]) as char(2))) as [Year Month] 
	  ,(CAST(YEAR(f.[sensei_date]) as char(4)) + ' ' + Format(f.sensei_date, 'MMM', 'en-AU') ) as [Year MonthName]
	  ,case 
	      when f.[sensei_typename] = 'Budget' then f.[sensei_value]
	      else 0 
	      end as Budget
	  , case
	      when f.[sensei_typename] = 'Forecast' and s.[sensei_value] = 'false' then f.[sensei_value]
	      when f.[sensei_typename] = 'Forecast' and f.[sensei_date] >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1) then f.[sensei_value]
	      else 0 
	    end as Forecast
		,case 
		  when f.[sensei_typename] = 'Actual' and s.[sensei_value] = 'false' then f.[sensei_value]
		  when f.[sensei_typename] = 'Actual' and s.[sensei_value] = 'true' and f.[sensei_date] < DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1) then f.[sensei_value]
	      else 0 
	    end as Actual
	   ,case 
	      when f.[sensei_date] > DATEADD(ss, -1, DATEADD(month, DATEDIFF(month, 0, getdate()), 0)) then 
		       case
				  when f.[sensei_typename] = 'Forecast' then f.[sensei_value]
	              else 0 
				  end
	      else 
		       case
		  		  when f.[sensei_typename] = 'Actual' then f.[sensei_value]
	              else 0 
				  end
	      end as EAC
	  ,f.[statuscodename] as [Status]
      ,f.[sensei_value] as [Value]
      ,f.[sensei_financialitemname] as [Financial Item Name]
	  ,fc.[sensei_name] as [Financial Subcategory]
	  ,fc.sensei_parentfinancialcategoryname as ParentCategory
	  , case
			when fc.sensei_parentfinancialcategoryname IS NULL then fc.[sensei_name]
			else fc.sensei_parentfinancialcategoryname
			end as ParentGrouping
      ,f.[sensei_project] as [Project Id]
	  ,p.sensei_name as [Project Name]


FROM  dbo.sensei_project p 
      left join [dbo].[sensei_financialtransaction]f on p.sensei_projectid = f.sensei_project 
	  left join dbo.sensei_financialitem fi on f.sensei_financialitem = fi.sensei_financialitemid
	  left join [dbo].[sensei_financialcategory] fc on fi.sensei_financialcategory =fc.sensei_financialcategoryid  
	  cross join [dbo].[sensei_senseiconfigsettings] s
where p.sensei_projectid = f.sensei_project
AND s.sensei_name = 'financialsSummariseTotals'
AND fc.[sensei_financialcategoryid] = fi.sensei_financialcategory
AND fi.sensei_financialitemid = f.sensei_financialitem
      and f.sensei_project = (@ProjUID)

	  --select * from sensei_financialtransaction -- forecast - current month >= sensei_date actuals - sensei_date < current month

	  --select * from sensei_senseiconfigsettings where sensei_name = 'financialsSummariseTotals' and sensei_value = 'true' and statecode = 0 --active (Yes) and sensei_value can be either true or false

	  --	  select * from sensei_senseiconfigsettings where sensei_name = 'financialsSummariseTotals' and sensei_value = false and statecode = 1 --inactive (No) 