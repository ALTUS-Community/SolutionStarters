--declare @environmenturl varchar(50)
--set @environmenturl = 'org2381711c.crm'
--Declare @ProjUID varchar(50)
--set @ProjUID = '7FEB9D74-7A58-EF11-BFE3-000D3AE1A88F'


SELECT
	Pj.sensei_projectid as [Project Id],
	Pj.sensei_name AS [Project Name],
	concat('https://', '@environmenturl', '.dynamics.com/main.aspx?appid=', app.appmoduleid, '&pagetype=entityrecord&etn=sensei_project&id=', Pj.sensei_projectid) AS Project_URL,
	St.sensei_stageentered AS Project_Phase,
	Pj.sensei_projectmanagername AS [Project Manager],
	Pj.sensei_sponsorname AS Sponsor,
	(Pj.sensei_percentcomplete / 100.0) AS [Percent Complete],
	Pj.sensei_projectstart AS [Start Date],
	Pj.sensei_targetfinish AS [Target Finish Date],
	Pj.sensei_projectfinish AS [Scheduled Finish Date],
	Pj.sensei_investmentcategoryname AS [Investment Category],
	Pj.sensei_departmentname AS [Department],
	Pj.sensei_efforttotal as [Effort Total],
	Pj.sensei_effortcompleted as [Effort Completed],
	Pj.sensei_location as [Location],
	Pj.sensei_returnoninvestment as [ROI],
	(Pj.sensei_efforttotal - Pj.sensei_effortcompleted) AS [Effort Remaining],
	Pj.sensei_portfolioname AS [Portfolio Name],
	Pj.sensei_programname AS [Program Name],
	Pj.sensei_description as [Description],
	Pj.sensei_baselinestart as [Baseline Start Date],
	Pj.sensei_baselinefinish as [Baseline Finish Date],
	Pj.sensei_baselineefforttotal as [Baseline Effort],
	Pj.sensei_baselinedurationweekdays as [Baseline Duration],
	Pj.sensei_effortvariance as [Baseline Effort Variance],
	Pj.sensei_finishvariance as [Baseline Finish Variance],
	Pj.transactioncurrencyidname as [Project Currency],
	Pj.sensei_problemstatement as [Problem Statement],
	Pj.sensei_businessbenefits as [Business Benefits],
	Pj.sensei_proposedcosts as [Proposal Costs],
	Pj.sensei_financialbenefits as [Financial Benefits],
	b.sensei_name as [Baseline Name]

		   	  
FROM sensei_project AS Pj
		LEFT JOIN (
					SELECT RankedEntries.sensei_primaryentityid,
						   RankedEntries.sensei_stageentered
					  FROM (
							SELECT 	Bp.sensei_primaryentityid,
									Bp.sensei_stageentered,
									ROW_NUMBER() OVER (
									PARTITION BY Bp.sensei_primaryentityid 
									ORDER BY Bp.sensei_dateentered DESC
									) AS rn
							 FROM sensei_businessprocessflowlog AS Bp
							WHERE Bp.sensei_primaryentity = 'sensei_project'
							) AS RankedEntries
				   WHERE RankedEntries.rn = 1
				  ) AS St ON Pj.sensei_projectid = St.sensei_primaryentityid
	   LEFT JOIN sensei_baseline b on b.sensei_project = pj.sensei_projectid
		CROSS JOIN (
				  SELECT appmoduleid 
					FROM appmodule 
				   WHERE uniquename = 'sensei_kaizen'
				   ) AS app
WHERE Pj.[sensei_projectid] = @ProjUID