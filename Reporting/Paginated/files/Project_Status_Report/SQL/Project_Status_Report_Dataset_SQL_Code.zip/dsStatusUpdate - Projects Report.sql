Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '7FEB9D74-7A58-EF11-BFE3-000D3AE1A88F'

SELECT 	* ,
	   StatusUpdate_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_statusupdate&id=',st.[Status Update Id])
	      FROM (
		SELECT x.sensei_project as [Project Id],
			   x.CreatedOn,
			   x.[sensei_statusdate] as [Status Date],
			   X.Statuscomment as [Status Comment],
			   x.KPIType,
			   x.KPI,
			   x.[sensei_statusupdateid] as [Status Update Id],
			   CASE
				 WHEN x.sensei_project IS NOT NULL THEN Row_number()
				 OVER (
				   partition BY x.sensei_project, x.KPIType
				   ORDER BY x.sensei_statusdate DESC)
				 ELSE NULL
			   END AS ProjectCommentRN,--whats ProjectCommentRN
			   CASE
				 WHEN x.sensei_project IS NOT NULL THEN Row_number()
				 OVER (
				   partition BY x.sensei_project, x.KPIType, x.[sensei_statusdate]
				   ORDER BY x.sensei_statusdate DESC)
				 ELSE NULL
			   END AS ProjectCommentRNPM  --whats ProjectCommentRNPM

		 FROM  ( SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_changerequestsstatus as Statuscomment,
					   'Change Status KPI' AS 'KPIType',
						CASE [sensei_changerequestskpi]
							--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--No KPI
							WHEN -1 THEN 3
							--Custom KPI
							ELSE 4
						END AS KPI
			 	 FROM   [dbo].[sensei_statusupdate] s
				 WHERE ( s.sensei_project IS NOT NULL AND s.sensei_project = (@ProjUID))
				 UNION ALL
				 SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_projectstatus,
					   'Project KPI'  AS 'KPIType',
					   CASE [sensei_projectkpi]
						 	--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_project IS NOT NULL AND s.sensei_project = (@ProjUID))
				UNION ALL
				SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_financialsstatus,
					   'Financials KPI' AS 'KPIType',
					   CASE [sensei_financialskpi]
							--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  (s.sensei_project IS NOT NULL )
				UNION ALL
				SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_deliverablesstatus,
					   'Deliverable KPI' AS 'KPIType',
					   CASE [sensei_deliverableskpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_project IS NOT NULL AND s.sensei_project = (@ProjUID))
				UNION ALL
				SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_risksstatus,
					   'Risk KPI' AS 'KPIType',
					   CASE [sensei_riskskpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  (s.sensei_project IS NOT NULL )
				UNION ALL
				SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_issuesstatus,
					   'Issue KPI' AS 'KPIType',
					   CASE [sensei_issueskpi]
							--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  (s.sensei_project IS NOT NULL )
				UNION ALL
				SELECT 
					  s.sensei_project as sensei_project,
					  s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_schedulestatus,
					   'Schedule KPI' AS 'KPIType',
					   CASE [sensei_schedulekpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_project IS NOT NULL AND s.sensei_project = (@ProjUID))
				UNION ALL
				SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_workstatus,
					   'Work KPI' AS 'KPIType',
					   CASE [sensei_workkpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE ( s.sensei_project IS NOT NULL AND s.sensei_project = (@ProjUID))
				UNION ALL
				SELECT 
					   s.sensei_project as sensei_project,
					   s.[sensei_statusupdateid],
					   Dateadd(hour, 10, createdon) AS CreatedOn,
					   s.[sensei_statusdate],
					   s.sensei_changerequestsstatus,
					   'Change Request KPI' AS 'KPIType',
					   CASE [sensei_changerequestskpi]
					   		--on track--
							WHEN  955000000 THEN 0
							--on watch--
							WHEN 955000001 THEN 1
							--troubled--
							WHEN 955000002 THEN 2
							--Null
							WHEN -1 THEN 3
							ELSE 4
						END AS KPI
				FROM   [dbo].[sensei_statusupdate] s
				WHERE  ( s.sensei_project IS NOT NULL AND s.sensei_project = (@ProjUID))
				) X  
			 
				 WHERE x.sensei_project = (@ProjUID)
			) AS st
		CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app
		WHERE st.ProjectCommentRN <= 2
		ORDER BY [Project Id], KPIType, ProjectCommentRN