Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '9946E29F-EAAC-4F63-90F7-473695100ED4'

 SELECT k.sensei_project as [Project Id]   ,
        k.sensei_projectname as [Project Name],
        k.sensei_keydateid as [Keydate Id] ,
        k.sensei_name as [KeyDate Name]   ,
        k.sensei_date as [Date]           ,
        k.sensei_description as [Description],
        k.statuscodename as [Status]       ,
        CASE
        WHEN
                k.statuscodename = 'Done'
        THEN
                0
        WHEN
                k.sensei_date < Getdate()
        THEN
                4
        WHEN
                k.sensei_date is null
        THEN
                3
        ELSE
                1
        END as StatusKPI,
        CASE
        WHEN
                k.statuscodename = 'Done'
        THEN
                'Completed'
        WHEN
                k.sensei_date < Getdate()
        THEN
                'Overdue'
        WHEN
                k.sensei_date is null
        THEN
                'Due Date Missing'
        ELSE
                'On Track'
        END as StatusKPITooltip,
        KeyDate_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_keydate&id=',k.sensei_keydateid)
  FROM [dbo].[sensei_keydate] k CROSS JOIN
        (
          SELECT appmoduleid
            FROM [dbo].[appmodule]
           WHERE [uniquename] = 'sensei_kaizen') app 
 WHERE k.sensei_project is not null
       and k.sensei_project = (@ProjUID)