Declare @EnvironmentURL varchar(50)
set @EnvironmentURL = 'altusaer.crm6'
Declare @ProjUID varchar(50)
set @ProjUID = '9946E29F-EAAC-4F63-90F7-473695100ED4'

SELECT 
c.sensei_project as [Project Id],
c.sensei_projectname as [Project Name],
c.sensei_changerequestid as [Change Request Id],
c.sensei_name as [Change Request Name],
c.sensei_description as [Description],
c.sensei_drivenbyname as [Driven by],
c.sensei_implementationdate as [Implementation Date],
c.sensei_categoryname as [Category],
c.sensei_priorityname as [Priority],
c.sensei_assignedtoname as [Assigned To],
c.sensei_workeffortestimate as [Work Effort Estimate],
c.sensei_workeffortdetails as [Work Effort Details],
c.sensei_costestimate as [Cost Estimate],
c.sensei_costestimatedetails as [Cost Estimate Details],
c.sensei_durationestimate as [Duration Estimate],
c.sensei_durationestimatedetails as [Duration Estimate Details],
c.sensei_resourceimpacts as [Resource Impacts],
c.sensei_impactonotherprojects as [Impact on Other Projects],
c.sensei_assumptions as [Assumptions],
c.sensei_approvedrejectedbyname as [Approved Rejected By],
c.sensei_approvedrejecteddate as [Approved Rejected Date],
c.sensei_duedate as [Due Date],
c.statuscodename as [Status],
case 
	when c.statuscodename = 'Approved' then 0
	when c.statuscodename = 'Rejected' then 0
	when c.statuscodename = 'On Hold' then 2
	when c.sensei_duedate < Getdate() then 4 
    when c.sensei_duedate is null then 3 
	else 1 
	end as StatusKPI,


case 
	when c.statuscodename = 'Approved' then 'Completed'
	when c.statuscodename = 'Rejected' then 'Completed'
	when c.statuscodename = 'On Hold' then 'On Hold'
	when c.sensei_duedate < Getdate() then 'Overdue'  
    when c.sensei_duedate is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,
	
c.[sensei_includeinprogramreportname] as [Include in Program Report],
c.[sensei_includeinpsrname] as [Include in PSR],
Changes_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_changerequest&id=',c.sensei_changerequestid)


 FROM [dbo].[sensei_changerequest] c
 CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

 where c.sensei_project is not null
    and c.sensei_project = (@ProjUID)
 and c.sensei_includeinpsr = 1