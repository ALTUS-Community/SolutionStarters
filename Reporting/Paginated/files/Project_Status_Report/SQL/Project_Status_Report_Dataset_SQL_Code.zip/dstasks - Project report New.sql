--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProjUID varchar(50)
--set @ProjUID = '4C7B0F1E-7A9F-4FB2-BFED-AEA72A73FEDA'

SELECT  distinct
        t.[sensei_project] as [Project Id],
        t.[sensei_taskid] as [Task Id],
        t.[sensei_name] as [Task Name],
        t.[sensei_categoryname] as [Category],
        t.[sensei_duedate] as [Due Date],
        t.[sensei_notes] as [Notes],
        t.[sensei_summaryname] as [Summary Task],       
        t.[sensei_milestonename] as [Milestone],
        t.[sensei_taskstart] as [Task Start],
        t.[sensei_duration] as [Duration],
        t.[sensei_taskfinish] as [Task Finish],
        t.[sensei_effort] as [Effort],
        t.[sensei_effortcompleted] as [Effort Completed],
        t.[sensei_effortremaining] as [Effort Remaining],
        t.[sensei_percentcomplete] as [Percent Complete],
        t.[sensei_level]  as [Task Level],
        t.[sensei_sprintname]  as [Sprint Name],
        t.[sensei_bucketname] as [Bucket Name],
        t.[sensei_size] as [Size],
		b.[sensei_taskfinish] as [Baseline Finish Date],

        CASE
        WHEN t.sensei_percentcomplete >= '100'
        THEN 0
        WHEN t.sensei_percentcomplete < '100' and t.sensei_taskfinish < Getdate()
        THEN 4
        ELSE 1
        End as StatusKPI,

        CASE
        WHEN t.sensei_percentcomplete >= '100'
        THEN 'Completed'
        WHEN t.sensei_taskfinish < Getdate()
        THEN 'Overdue'
        ELSE 'On Track'
        End as StatusKPITooltip,
		proj.sensei_name as ProjectName,
        Task_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_task&id=',t.[sensei_taskid])
        FROM [dbo].[sensei_task] t left JOIN [sensei_taskbaseline] b on b.sensei_taskid = t.sensei_taskid
		     CROSS JOIN
								   (SELECT appmoduleid
									  FROM [dbo].[appmodule]
			                         WHERE [uniquename] = 'sensei_kaizen') app 
			 LEFT JOIN dbo.sensei_project proj on proj.sensei_projectid = t.sensei_project
	   WHERE t.sensei_project is not null
			 and proj.sensei_projectid = (@ProjUID)