--Declare @EnvironmentURL varchar(50)
--set @EnvironmentURL = 'altusaer.crm6'
--Declare @ProjUID varchar(50)
--set @ProjUID = '9946E29F-EAAC-4F63-90F7-473695100ED4'

SELECT 

d.sensei_project as [Project Id],
d.sensei_projectname as [Project Name],
d.sensei_deliverableid as [Deliverable Id],
d.sensei_name as [Deliverable Name],
d.sensei_description as [Description],
d.sensei_progressupdate as [Progress Update],
d.sensei_categoryname as [Category],
d.sensei_assignedtoname as [Assigned To],
d.sensei_duedate as [Due Date],
d.statuscodename as [Status],
case 
	when d.statuscodename = 'Completed' then 0
	when d.statuscodename = 'Cancelled' then 0
	when d.sensei_duedate < Getdate() then 4 
    when d.sensei_duedate is null then 3 
	else 1 
	end as StatusKPI,

case 
	when d.statuscodename = 'Completed' then 'Completed'
	when d.statuscodename = 'Cancelled' then 'Completed'
	when d.sensei_duedate < Getdate() then 'Overdue'
    when d.sensei_duedate is null then 'Due Date Missing'
	else 'On Track' 
	end as StatusKPITooltip,
    d.[sensei_includeinprogramreportname] as [Include in Program Report],
    d.[sensei_includeinpsrname] as [Include in PSR],

Deliverable_URL = concat('https://',(@EnvironmentURL),'.dynamics.com/main.aspx?appid=',app.appmoduleid,'&pagetype=entityrecord&etn=sensei_deliverable&id=',d.sensei_deliverableid)


 FROM [dbo].[sensei_deliverable] d
 CROSS JOIN ( SELECT appmoduleid FROM [dbo].[appmodule] WHERE [uniquename] = 'sensei_kaizen') app

 where d.sensei_project is not null
   and d.sensei_project = (@ProjUID)
 and d.sensei_includeinpsr = 1